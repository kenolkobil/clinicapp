package com.example.e_clinicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class registerpatient extends AppCompatActivity {
   private EditText r1,r2,r3,r4,r5,r6,r7;
   Button register;
   DBmanager mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerpatient);
        r1=(EditText) findViewById(R.id.r1);
        r2=(EditText) findViewById(R.id.r2);
        r3=(EditText) findViewById(R.id.r3);
        r4=(EditText) findViewById(R.id.r4);
        r5=(EditText) findViewById(R.id.r5);
        r6=(EditText) findViewById(R.id.r6);
        r7=(EditText) findViewById(R.id.r7);
        mydb=new DBmanager(this);
        register=findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClickMe();
            }
        });
    }
    //public void addrecord(View view){
        //DBmanager db=new DBmanager(this);
        //String res=db.addrecord(r1.getText().toString(),r2.getText().toString(),r3.getText().toString(),r4.getText().toString(),r5.getText().toString(),r6.getText().toString(),r7.getText().toString());
       // Toast.makeText(this,res,Toast.LENGTH_LONG).show();
    // r1.setText("");
       // r2.setText("");
        //r3.setText("");
        //r4.setText("");
        //r5.setText("");
        //r6.setText("");
        //r7.setText("");


   // }
    private void ClickMe(){
        String p1=r1.getText().toString();
        String p2=r2.getText().toString();
        String p3=r3.getText().toString();
        String p4=r4.getText().toString();
        String p5=r5.getText().toString();
        String p6=r6.getText().toString();
        String p7=r7.getText().toString();
        Boolean result=mydb.insertData(p1,p2,p3,p4,p5,p6,p7);
        if (result==true){
            Toast.makeText(this,"data inserted successfully",Toast.LENGTH_SHORT).show();
        }
        else {Toast.makeText(this,"data insertion failed",Toast.LENGTH_SHORT).show();

        }

    }
}