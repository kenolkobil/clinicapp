package com.example.e_clinicapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Adminpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminpage);
    }
}